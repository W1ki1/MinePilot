package pl.pixeloza.mc_ai_recorder.client.hud;

import pl.pixeloza.mc_ai_recorder.client.inference.AiAction;

public final class AiDebugState {
    private AiDebugState() {
    }

    public static volatile boolean hudVisible = true;

    public static volatile boolean tcpEnabled = false;
    public static volatile boolean aiControlEnabled = false;
    public static volatile boolean connected = false;

    public static volatile String protocolState =
            "OFF";

    public static volatile String serverEndpoint =
            "UNCONFIGURED";

    public static volatile String serverMode =
            "UNKNOWN";

    public static volatile String serverRelease =
            "UNSPECIFIED";

    public static volatile String lastProtocolAction =
            null;

    public static volatile String lastRoute =
            "SAFE_IDLE";

    public static volatile String lastGuiResult =
            "---";

    public static volatile long lastObservationSequenceId =
            -1L;

    public static volatile long lastActionSequenceId =
            -1L;

    public static volatile AiAction lastAction = null;

    public static volatile long lastInferenceMs = -1;
    public static volatile long lastRoundtripMs = -1;

    public static volatile int jpegSize = 0;

    public static volatile String navigationPhase = "---";
    public static volatile String navigationDirection = "---";
    public static volatile double navigationLeftScore = Double.NaN;
    public static volatile double navigationRightScore = Double.NaN;
    public static volatile boolean navigationTieBreak = false;
}
