package pl.pixeloza.mc_ai_recorder.client.recording;

import com.google.gson.Gson;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;

public final class RuntimeObservationFactory {
    private static final int FRAME_WIDTH =
            224;

    private static final int FRAME_HEIGHT =
            224;

    private static final int JPEG_QUALITY =
            80;

    private final Gson gson =
            new Gson();

    public JsonObject create(
            Minecraft client,
            long tick,
            Long lastAppliedActionSequenceId,
            boolean controlEnabled
    ) {
        WorldStepSnapshot worldStep =
                SnapshotFactory.createWorldStep(
                        client,
                        0,
                        tick,
                        "",
                        null,
                        null,
                        null,
                        0.0f,
                        0.0f,
                        null
                );

        JsonObject observation =
                gson.toJsonTree(
                        worldStep
                ).getAsJsonObject();

        observation.remove(
                "recordType"
        );

        observation.remove(
                "sequenceId"
        );

        observation.remove(
                "frame"
        );

        observation.remove(
                "action"
        );

        observation.addProperty(
                "protocolVersion",
                2
        );

        observation.addProperty(
                "schemaVersion",
                2
        );

        observation.addProperty(
                "controlEnabled",
                controlEnabled
        );

        if (lastAppliedActionSequenceId == null) {
            observation.add(
                    "lastAppliedActionSequenceId",
                    JsonNull.INSTANCE
            );
        } else {
            observation.addProperty(
                    "lastAppliedActionSequenceId",
                    lastAppliedActionSequenceId
            );
        }

        InventoryCapture inventoryCapture =
                SnapshotFactory.captureInventory(
                        client.player
                );

        observation.add(
                "runtimeInventory",
                gson.toJsonTree(
                        inventoryCapture
                )
        );

        WorldCapture worldCapture =
                SnapshotFactory.captureLocalWorld(
                        client
                );

        JsonObject runtimeWorld =
                gson.toJsonTree(
                        worldCapture
                ).getAsJsonObject();

        /*
         * The fingerprint is used internally for recording revisions.
         * Runtime inference only needs origin, bounds and blocks.
         */
        runtimeWorld.remove(
                "fingerprint"
        );

        observation.add(
                "runtimeWorld",
                runtimeWorld
        );

        JsonObject gui =
                observation.getAsJsonObject(
                        "gui"
                );

        if (client.screen
                instanceof AbstractContainerScreen<?> containerScreen) {
            ContainerSourceSnapshot source =
                    SnapshotFactory.containerSource(
                            client,
                            client.screen
                    );

            ContainerCapture containerCapture =
                    SnapshotFactory.captureContainer(
                            client,
                            client.screen,
                            source
                    );

            JsonObject runtimeContainer =
                    gson.toJsonTree(
                            containerCapture
                    ).getAsJsonObject();

            ItemStackSnapshot carried =
                    ItemStackSnapshot.from(
                            containerScreen
                                    .getMenu()
                                    .getCarried()
                    );

            runtimeContainer.add(
                    "carried",
                    gson.toJsonTree(
                            carried
                    )
            );

            String runtimeFingerprint =
                    RuntimeContainerInspector
                            .fingerprint(
                                    client,
                                    client.screen
                            );

            runtimeContainer.addProperty(
                    "fingerprint",
                    runtimeFingerprint
            );

            observation.add(
                    "runtimeContainer",
                    runtimeContainer
            );

            gui.addProperty(
                    "slotCount",
                    containerCapture.slotCount()
            );

            gui.addProperty(
                    "containerFingerprint",
                    runtimeFingerprint
            );
        } else {
            observation.add(
                    "runtimeContainer",
                    JsonNull.INSTANCE
            );

            gui.addProperty(
                    "slotCount",
                    0
            );

            gui.add(
                    "containerFingerprint",
                    JsonNull.INSTANCE
            );
        }

        JsonObject frame =
                new JsonObject();

        frame.addProperty(
                "format",
                "JPEG"
        );

        frame.addProperty(
                "width",
                FRAME_WIDTH
        );

        frame.addProperty(
                "height",
                FRAME_HEIGHT
        );

        frame.addProperty(
                "quality",
                JPEG_QUALITY
        );

        observation.add(
                "frame",
                frame
        );

        return observation;
    }
}
